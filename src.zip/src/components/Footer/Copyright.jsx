import React from 'react' 
import {Row , Col, Typography} from 'antd'

const {Paragraph} = Typography
const Copyright = () => {
    const year = new Date().getFullYear()
    return (
      <footer className='bg-primary py-2'>
       <div className='container'>
          <Row>
              <Col span={24}>
              <Paragraph className=' mb-0 text-white text-center'>&copy; {year}. All rights Reserved</Paragraph>
              
             </Col>
          </Row>
       </div>
      </footer>
  )
}

export default Copyright
