import React, { createContext , useCallback, useContext, useEffect, useState } from 'react'
import {onAuthStateChanged, signOut} from "firebase/auth"
import { auth, firestore } from 'config/firebase'
import { doc, getDoc } from 'firebase/firestore'


const AuthContext = createContext()
const initialState = {isAuth:false , user:{}}
const AuthProvider = ({children}) => {
    const [state , dispatch] = useState(initialState)
    const [isAppLoading , setIsAppLoading ] = useState(true)
const readProfile= useCallback(async(user)=>{

const docSnap = await getDoc(doc(firestore, "users", user.uid));

if (docSnap.exists()) {
        const user = docSnap.data()
        console.log('Firestore user Data', user)
  dispatch(s=>({...s , isAuth:true , user }))
} else {
 
  console.log("No such document!");
}
    setIsAppLoading(false)  
},[])    
    useEffect(()=>{
    onAuthStateChanged(auth, (user) => {
  if (user) {
    readProfile(user)
   console.log('Auth user Data', user)
    
  } else {
    console.log("user is logout ")
    setTimeout(() => {  setIsAppLoading(false)  }, 1000);
  }
  
});
},[])
const handleLogout = ()=>{
      signOut(auth)
      .then(() =>{
        dispatch(initialState)
        window.tostify("Logout successful" , "success")
      })
      .catch((error)=>{
        window.tostify("something went wrong while signing out user" , "error")
        console.error(error)
      })
}

  return (
    <AuthContext.Provider value={{...state , setAuthState: dispatch , isAppLoading ,  handleLogout}}>
        {children}
    </AuthContext.Provider>
  )
}

export const useAuthContext = ()=>useContext(AuthContext)
export default AuthProvider
