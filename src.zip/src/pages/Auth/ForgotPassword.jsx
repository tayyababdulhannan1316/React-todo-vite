import { Typography } from 'antd'
import React from 'react'
const {Title} = Typography
const ForgotPassword = () => {
  return (
    <>
      <Title level={1} className='text-center'>Forgot Password</Title>
    </>
  )
}

export default ForgotPassword
