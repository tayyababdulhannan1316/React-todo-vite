import { Button, Col, Form, Input, message, Row, Typography } from "antd";

import React, { useState } from "react";
import { auth } from "../../config/firebase";
import {  signInWithEmailAndPassword } from "firebase/auth";
import { useNavigate } from "react-router-dom";

const initialState = { email:"" , password:"" }
const {Title} = Typography
const Login = () => {
    const [state , setState] = useState(initialState)
    // const navigate = useNavigate()
    const [isProcessing , setIsProcessing] = useState(false)
  const handleChange = e => setState(s=>({...s , [e.target.name]:e.target.value}))
  const handleSubmit = (e) => {
    e.preventDefault();
    let { email, password} = state
      
    setIsProcessing(true)
    signInWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
     
    const user = userCredential.user;
    console.log('user', user)
   
  })
  .catch((error) => {
      window.tostify("something went wrong while Signing in user","error")
    setIsProcessing(false)
  })
  .finally(() => {
   
    setIsProcessing(false)
  });
    // navigate("/")

    };
  
  return (
    <main className="auth p-3 p-md-4 p-lg-5">
      <div className="conatiner">
        <div className="card p-3 p-md-4">
        <Title className="text-primary text-center mb-5" >Login</Title>
          <Form layout="vertical">
            <Row gutter={16}>
               <Col span={24}>
                <Form.Item label="Email" required>
                  <Input type="email" placeholder="Enter your email" name="email"onChange={handleChange}></Input>
                </Form.Item>
                </Col>
                <Col span={24}>
                <Form.Item label="Password" required>
                  <Input.Password  placeholder="Enter your password" name="password"onChange={handleChange}></Input.Password>
                </Form.Item>
              </Col>
              <Col span={24}>
                <Button type="primary" block htmlType="submit" loading={isProcessing} onClick={handleSubmit}>Login</Button>
              </Col>
            
            </Row>
          </Form>
        </div>
      </div>
    </main>
  );
};

export default Login;
