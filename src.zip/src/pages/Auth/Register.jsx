import React, { useState } from "react";
import { Button, Col, Form, Input, message, Row, Typography } from "antd";
import { auth, firestore } from "../../config/firebase";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { addDoc, collection, doc, setDoc } from "firebase/firestore";

const initialState = {firstName:"" , lastName:"" , email:"" , password:"" , confirmPassword:""}
const {Title} = Typography
const Register = () => {
    const [state , setState] = useState(initialState)
    const [isProcessing , setIsProcessing] = useState(false)
  const handleChange = e => setState(s=>({...s , [e.target.name]:e.target.value}))
  const handleSubmit = (e) => {
    e.preventDefault();
    let {firstName,lastName, email, password, confirmPassword} = state
    firstName = firstName.trim()
    lastName = lastName.trim()
    if(firstName.length<3){return window.tostify("please enter your fullname accurately","error")}
    if(lastName.length<3){return window.tostify("please enter your lastname accurately","error")}
    // if(!window.isEmail(email)){return window.tostify("please enter valid email")}
    if(password.length<6){return window.tostify("password must be atleast 6 characters ","error")}
    if(password != confirmPassword){return window.tostify("password and confirmpassword does not match","error")}
    const userData = {firstName,lastName, email}
    setIsProcessing(true)
    createUserWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
     
    const user = userCredential.user;
    console.log('user', user)
    createDocument({...userData , uid:user.uid})
  })
  .catch((error) => {
   window.tostify("something went wrong while creating user","error")
    setIsProcessing(false)
  });
    
    
    };
    const createDocument = async(userData)=>{
    console.log('userData', userData)
    const user = {...userData}
    try {
  // const docRef = await addDoc(collection(firestore, "users"), userData);
  await setDoc(doc(firestore, "users", user.uid), user);
  // console.log("Document written with ID: ", docRef.id);
  window.tostify("user created successfully","success")
} catch (e) {
  window.tostify("something went wrong while creating user","error")
  console.error("Error adding document: ", e);
} finally{
  setIsProcessing(false)
}
    
    }
  return (
    <main className="auth p-3 p-md-4 p-lg-5">
      <div className="conatiner">
        <div className="card p-3 p-md-4">
        <Title className="text-primary text-center mb-5" >Register</Title>
          <Form layout="vertical">
            <Row gutter={16}>
              <Col xs={24} md={12}>
                <Form.Item label="First Name" required>
                  <Input type="text" placeholder="Enter your firstName" name="firstName"onChange={handleChange}></Input>
                </Form.Item>
              </Col>
              <Col xs={24} md={12}>
                <Form.Item label="Last Name" >
                  <Input type="text" placeholder="Enter your lastName" name="lastName"onChange={handleChange}></Input>
                </Form.Item>
              </Col>
              <Col span={24}>
                <Form.Item label="Email" required>
                  <Input type="email" placeholder="Enter your email" name="email"onChange={handleChange}></Input>
                </Form.Item>
                </Col>
                <Col span={24}>
                <Form.Item label="Password" required>
                  <Input.Password  placeholder="Enter your password" name="password"onChange={handleChange}></Input.Password>
                </Form.Item>
              </Col>
              <Col span={24}>
                <Form.Item label="Confirm Password" required>
                  <Input.Password  placeholder="confirm your password" name="confirmPassword"onChange={handleChange}></Input.Password>
                </Form.Item>
              </Col>
              <Col span={24}>
                <Button type="primary" block htmlType="submit" loading={isProcessing} onClick={handleSubmit}>Register</Button>
              </Col>
            
            </Row>
          </Form>
        </div>
      </div>
    </main>
  );
};

export default Register;
