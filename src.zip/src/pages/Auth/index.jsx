import React from 'react'
import { Route, Routes } from 'react-router-dom'
import ForgotPassword from './ForgotPassword'
import Login from './Login'
import Register from './Register'
import NoPage from '../Misc/NoPage'

const Auth = () => {
  return (
    <>
     <Routes>
        <Route path='register' element={<Register />} />
        <Route path='login' element={<Login />} />
        <Route path='forgotpassword' element={<ForgotPassword />} />
        <Route path='*' element={<NoPage />} />
     </Routes> 
    </>
  )
}

export default Auth
