import React, { useState } from "react";
import { Button, Col, Form, Input, message, Row, Typography } from "antd";
import { auth, firestore, storage } from "../../../config/firebase";
import { createUserWithEmailAndPassword } from "firebase/auth";
import {  doc, serverTimestamp, setDoc } from "firebase/firestore";
import { useNavigate } from "react-router-dom";
import { useAuthContext } from "contexts/Auth";
import { getDownloadURL, ref, uploadBytesResumable } from "firebase/storage";

const initialState = {title:"" , location:"" , description:"" }
const {Title} = Typography
const Add = () => {
    const [state , setState] = useState(initialState)
    const [isProcessing , setIsProcessing] = useState(false)
    const [file , setFile] = useState(null)
    const {user} = useAuthContext()
    const navigate = useNavigate()
  const handleChange = e => setState(s=>({...s , [e.target.name]:e.target.value}))
  const handleSubmit = (e) => {
    e.preventDefault();
    let {title,location, description} = state
    title = title.trim()
    location = location.trim()
    if(title.length<3){return window.tostify("please enter your Todo title accurately","error")}
    
    const todo = {uid:user.uid , id:window.getRandomId() , title,location, description ,imageURL:"" , status:"Incompleted" ,createdAt:serverTimestamp()}
    console.log('file', file)
    
    setIsProcessing(true)
    if(file){
      handleUploadImage(todo)
    }else{
    createDocument(todo)
    }
    
      
    
    }

    const handleUploadImage =  (todo)=>{
      console.log('todo', todo)
      console.log('file', file)
    const fileName = window.getRandomId()+ "-" + file.name

      const storageRef = ref(storage, `images/${fileName}`);

const uploadTask = uploadBytesResumable(storageRef, file);

// Register three observers:
// 1. 'state_changed' observer, called any time the state changes
// 2. Error observer, called on failure
// 3. Completion observer, called on successful completion
uploadTask.on('state_changed', 
  (snapshot) => {
    // Observe state change events such as progress, pause, and resume
    // Get task progress, including the number of bytes uploaded and the total number of bytes to be uploaded
    const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
    console.log('Upload is ' + progress + '% done');
    switch (snapshot.state) {
      case 'paused':
        console.log('Upload is paused');
        break;
      case 'running':
        console.log('Upload is running');
        break;
    }
  }, 
  (error) => {
    setIsProcessing(false)
    window.tostify("something went wrong while uploading image" , "error")
  }, 
  () => {
    // Handle successful uploads on complete
    // For instance, get the download URL: https://firebasestorage.googleapis.com/...
    getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
      console.log('File available at', downloadURL);
      window.tostify("file uploaded successfully" , "success")
      createDocument({...todo , imageURL:downloadURL})
    });
  }
);

    }
    const createDocument = async(todo)=>{
   
    try {
 
  await setDoc(doc(firestore, "todos", todo.id), todo);
 
  window.tostify("todo created successfully","success")
  setState(initialState)
} catch (e) {
  window.tostify("something went wrong while creating todo","error")
  console.error("Error adding document: ", e);
} finally{
  setIsProcessing(false)
}
    
    }
  return (
    <main className="auth p-3 p-md-4 p-lg-5">
      <div className="conatiner">
        <div className="card p-3 p-md-4">
        <Title className="text-primary text-center mb-5" >Add Todo</Title>
          <Form layout="vertical">
            <Row gutter={16}>
              <Col span={24} >
                <Form.Item label="Title" required>
                  <Input type="text" placeholder="Enter Todo title" name="title" value={state.title} onChange={handleChange}></Input>
                </Form.Item>
              </Col>
              <Col span={24}>
                <Form.Item label="Location" >
                  <Input type="text" placeholder="Enter Todo location" name="location" value={state.location} onChange={handleChange}></Input>
                </Form.Item>
                </Col>
                 <Col span={24}>
                <Form.Item label="Description" >
                  <Input.TextArea  placeholder="Enter Todo description" style={{minHeight:100 , resize:"none"}} name="description" value={state.description}  onChange={handleChange}></Input.TextArea>
                </Form.Item>
                </Col>
                 <Col span={24}>
                <Form.Item label="Image" >
                  <Input type="file" className="form-control"  onChange={e => setFile(e.target.files[0])}></Input>
                </Form.Item>
                </Col>
               
              <Col span={12}>
                <Button type="primary" block htmlType="submit" loading={isProcessing} onClick={handleSubmit}>Add Todo</Button>
              </Col>
            <Col span={12}>
                <Button type="primary" block  onClick={()=>{navigate("/dashboard/todos/all")}}>All Todo</Button>
              </Col>
            </Row>
          </Form>
        </div>
      </div>
    </main>
  );
};

export default Add;
