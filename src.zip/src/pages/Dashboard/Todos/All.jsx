import { Col, Row, Typography , Button, Space, Image } from 'antd'
import React, { useCallback, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Todos from '.'
import { collection, deleteDoc, doc,  getDocs, query, serverTimestamp, setDoc, where } from 'firebase/firestore'
import { firestore } from 'config/firebase'
import { useAuthContext } from 'contexts/Auth'
const {Title} = Typography
const All = () => {
    const [todos , setTodos] = useState([])
    const navigate = useNavigate()
    
    const {user} = useAuthContext()
    const getTodos = useCallback(async()=>{

        if(user.uid){
        const q = query(collection(firestore, "todos"), where("uid", "==", user.uid));
        
        const querySnapshot = await getDocs(q);
        const array=[]
        querySnapshot.forEach((doc) => {
        const document = doc.data()
        console.log('Document', document)
        array.push(document)
        });
        setTodos(array)
        }

    } , [user.uid])

    useEffect(()=>{getTodos()},[getTodos])

    const handleUpdate = async (todo) =>{
        const updatedData = {status:"Completed" , updatedAt:serverTimestamp()  } 
            try {
         
          await setDoc(doc(firestore, "todos", todo.id), updatedData , {merge:true});
         
          window.tostify("todo updated successfully","success")
          
        } catch (e) {
          window.tostify("something went wrong while updating todo","error")
          console.error("Error adding document: ", e);
       

    }
}
    const handleDelete = async(todo) =>{
        try {
        await deleteDoc(doc(firestore, "todos", todo.id));
        window.tostify("todo Deleted successfully","success")

        } catch (e) {
          window.tostify("something went wrong while Deleting todo","error")
          console.error("Error Deleting document: ", e);
       

    }

        
    }
  return (
    <>
    <main className="p-5">
      <div className="conatiner">
         <Row>
         <Col span={24}>
        <Title className="text-primary text-center mb-5" >All Todo</Title>
        </Col>
        <Col span={24}>
            <table className="table">
  <thead>
    <tr>
      <th >#</th>
      <th >ID</th>
      <th >Image</th>
      <th >Title</th>
      <th >Location</th>
      <th >Description</th>
      <th >status</th>
      <th >Actions</th>
      
    </tr>
  </thead>
  <tbody>
 
    {todos.map((todo , i)=>{
        return    <tr key={i}>
      <th >{i+1}</th>
      <td>{todo.id}</td>
      <td><Image src={todo.imageURL} alt="todo" className='rounded-circle' style={{width:60 , height:60}} /></td>
      <td>{todo.title}</td>
      <td>{todo.location}</td>
      <td>{todo.description}</td>
      <td>{todo.status}</td>
      <td>
        <Space>
            <Button type='primary' size='small' onClick={()=>{handleUpdate(todo)}} >Edit</Button>
            <Button type='primary' size='small' danger onClick={()=>{handleDelete(todo)}} >Delete</Button>
        </Space>
      </td>
    </tr>
        
    })}
 
  </tbody>
</table>
        </Col>
        <Col span={24} className='text-center'>
        <Button type="primary"   onClick={()=>{navigate("/dashboard/todos/add")}}>Add Todo</Button>
        </Col>
       </Row>
        </div>
      
    </main>
    </>
  )
}

export default All
