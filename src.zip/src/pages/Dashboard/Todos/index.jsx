import React from 'react' 
import Add from "./Add"
import All from './All'
import { Route, Routes } from 'react-router-dom'
const Todos = () => {
  return (
    <>
     
     <Routes>
      <Route path='add' element={<Add />} />
      <Route path='all' element={<All />} />
     </Routes>
    </>
  )
}

export default Todos
