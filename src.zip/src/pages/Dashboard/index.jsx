import React from 'react'
import { Routes , Route, Navigate } from 'react-router-dom'
import Todos from './Todos'


const Dashboard = () => {
  return (
    <>
    
    <Routes>
        
        <Route index element={<Navigate to="/dashboard/todos/add" />} />
        <Route path="todos/*" element={<Todos />} />
      
      {/* <Route index element={<Navigate to="/dashboard/todos/add" />} /> 
      <Route path="todos/*" element={<Todos />} /> 
      <Route path="/dashboard/sidebar" element={<Navigate to="/dashboard/sidebar" />} /> */}
    </Routes> 
    
    </>
  )
}

export default Dashboard
