import React from 'react'
import {Typography , Row , Col} from 'antd'

const {Title, Paragraph} = Typography

const  About = () => {

  return (
    <main>
               
       <div className='container py-5 text-center'>
          <Row>
              <Col span={24}>
              <Title level={1}>About Section</Title>
              <Paragraph className=' text-center'> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy.</Paragraph>
              
             </Col>
          </Row>
       </div>
       
   {/* <Routes>
    <Route path='company' element={<Company />} />
    <Route path='team' element={<Team />} />
   </Routes> */}
      
    </main>
  )
}

export default About
