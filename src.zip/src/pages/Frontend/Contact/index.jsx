import React ,{useState} from 'react'

const  Contact = () => {
  let name = ""
let city = ""
const [colo , setColo] = useState("#fff");
const handleSubmit = (e) =>{
  e.preventDefault()
  console.log('name',name)
  console.log('city', city)
}
  return ( <main style={{backgroundColor:colo}}>
    <div className='container'>
      <div className='Row'>
        <div className='Col'>
          <div className='py-5 text-center  '>
          <h1 className='mb-2 '>This is Contact Page</h1>
          <input type='color' onChange={e => {setColo(e.target.value)}} />
          <form>
            <div className='row'>
              <div className='col-12 col-md-6'>
                <input type='text' placeholder='Enter your Name' className='form-control' onChange={(e)=>{name=e.target.value }} />
              </div>
              <div className='col-12 col-md-6'>
                <input type='text' placeholder='Enter your City' className='form-control' onChange={(e)=>{city=e.target.value }}  />
              </div>
              <div className='col-12 col-md-6 offset-md-3 mt-3'>
              <button className='btn btn-primary w-100' onClick={handleSubmit} >click me</button>
              </div>
            </div>
          </form>           
          </div>
        </div>
      </div>
    </div>
      
    </main>
  )
}

export default Contact
