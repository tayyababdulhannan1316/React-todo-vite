import React, { useState } from 'react' 
import {Typography , Row , Col, Button, Space} from 'antd'
import { useAuthContext } from 'contexts/Auth'
import { doc, setDoc } from 'firebase/firestore'
import { firestore } from 'config/firebase'

const {Title, Paragraph} = Typography
const Hero = () => {
  const {user} = useAuthContext()
  const [isProcessing , setIsProcessing] = useState(false)
  const [state , setState] = useState({firstName:"Muhammad" , lastName:"Shazain"})
  const handleUpdateProfile = async(status)=>{
      
   const {firstName , lastName} = state
   const upatedData = {firstName , lastName , status}
   
   setIsProcessing(true)
       try {
     await setDoc(doc(firestore, "users", user.uid), upatedData , {merge: true});
  
      window.tostify("user Profile upated successfully","success")
      } catch (e) {
      window.tostify("Error while updating  user profile","error")
      console.error("Error on Updating document: ", e);
      } finally{
      setIsProcessing(false)
      }
  }
   return (
               
       <div className='container py-5 text-center'>
          <Row>
              <Col span={24}>
              
              <Title level={2}>FirstName: {user.firstName}</Title>
              <Title level={2}>LastName: {user.lastName}</Title>
              <Title level={1}>Hero Section</Title>
              <Title level={2}>Email: {user.email}</Title>
              <Title level={2}>User Id: {user.uid}</Title>
             
              <Paragraph className=' text-center'> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy.</Paragraph>
              
             </Col>
             <Col span={24} className='text-center'>
             <Space>
             <Button type='primary' loading={isProcessing} onClick={()=>{handleUpdateProfile("Active")}}>Profile Active</Button>
             <Button type='primary' loading={isProcessing} onClick={()=>{handleUpdateProfile("Inactive")}}>Profile Inactive</Button>
             </Space>
             </Col>
          </Row>
       </div>
       
   
  )
}

export default Hero
