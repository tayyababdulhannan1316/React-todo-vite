import React from 'react'
import {Button, Col, Row, Typography } from 'antd'
import { useNavigate } from 'react-router-dom';

const {Title} = Typography

const NoPage = () => {
 
  const navigate = useNavigate()
  const handleNavigate=()=>{
  navigate('/')
  }
  return (
        
     <main className="text-center">
     <div className='container border border-3 border-primary mt-5'>
      <Row>
        <Col span={24}>
          <Title level={1} className='m-5 ' style={{color:"#1D3557"}} >404. No Page Found.</Title>
     <Title level={4} className='mt-3 text-center' >The page you are looking for is no longer exists or never existed.<br/> Go to the site's home page and see if you can find what you are looking for.</Title>
     <Button type='primary' size='large' className='mt-4 mb-4' onClick={handleNavigate}>Back To Home</Button>
        </Col>
      </Row>
     </div>       
     </main>
  )
};

export default NoPage;